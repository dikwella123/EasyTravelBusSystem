<?php
$lang['First name'] = "Erita elyaberi";
$lang['Last name'] = "Erita erisembayo";
$lang['ID number'] = "Enamba ya identicadi";
$lang['Departure'] = "yotula";
$lang['Arrival'] = "Iwolera";
$lang['Departure time'] = "Esawa kyo werawo";
$lang['Return time'] = "Esawa kyo funyiramu";
$lang['Booked by'] = "A pangise eticket";
$lang['Modified by'] = "Akyusire obuwandike bwe ticket";
$lang['Options'] = "options";
$lang['Book a ticket'] = "pangisa e ticket ye Basi";
$lang['Search'] = "konya";
$lang['Departure city'] = "Etawuuni yotula";
$lang['Arrival city'] = "Etawuuni yo kya";
$lang['Departure date'] = "oludalo lwo kira";
$lang['Return date'] = "oludalo lwo funya";
$lang['Tickets'] = "Eticket";
$lang['Returning'] = "okobolera";
$lang['Reset'] = "ohengamu eticket yawo";
$lang['Check available tours'] = "konya e busi itechula";
$lang['Optional'] = "ebundi bindi";
$lang['Your search results will be displayed here'] = "bwo konyeresa bi naba ano";
$lang['Destination'] = "esitudu sio kyamo";
$lang['Price'] = "esende ki eticket ikula";
$lang['Next'] = "esidi";
$lang['Currently there are no tours available'] = "ngo bwene ebasi iwumawo eyi cha eyo!";
$lang['from'] = 'itula';
$lang['to'] = 'icha';
$lang['Booking details'] = "ebidira hu eticketi yawo";
$lang['Ticket details'] = "bwosi ebye ticket";
$lang['Ticket(s) booked successfully'] = "Webale o pangisa eticketi yawo";
$lang['Ticket for'] = "eticketi ya";
$lang['was booked successfully'] = "opangise eticket bulayi";
$lang['Print invoice'] = "Sohora inyemeza buguzi";
$lang['Go back to search'] = "Subira inyuma mw'ishakiro";



?>
