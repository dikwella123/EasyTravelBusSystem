<?php
$lang['Clients'] = "Clients";
$lang['First name'] = "First name";
$lang['Last name'] = "Last name";
$lang['ID number'] = "ID number";
$lang['Total tickets'] = "Total tickets";
$lang['Options'] = "Options";
$lang['Booking history'] = "Booking history";
$lang['Search client'] = "Search client";
$lang['Departure'] = "Departure";
$lang['Arrival'] = "Arrival";
$lang['Direction'] = "Direction";
$lang['One way'] = "One way";
$lang['Returning'] = "Returning";


?>
