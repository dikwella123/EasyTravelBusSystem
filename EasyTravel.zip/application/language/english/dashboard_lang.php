<?php
$lang['Your stats'] = "Easy Travel Statistics";
$lang['Your username'] = "Your username";
$lang['Your role'] = "Your role";
$lang['Total tickets sold last 7 days'] = "Total tickets sold last 7 days";
$lang['Total tickets sold this month'] = "Total tickets sold this month";
$lang['Total tickets sold'] = "Total tickets sold";
$lang['Dashboard'] = "Dashboard";
$lang['Available tours'] = "Available Bus Tours";
$lang['Departure'] = "Departure";
$lang['Arrival'] = "Arrival";
$lang['Departure at'] = "Departure at";
$lang['Quick booking'] = "Quick booking";
$lang['Book ticket'] = "Book ticket";
$lang['Search & Book Tickets'] = "Search & Book Tickets";
?>
