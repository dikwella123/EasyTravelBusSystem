<?php
$lang['Destinations'] = "Destinations";
$lang['City'] = "City";
$lang['ISO name'] = "ISO name";
$lang['Options'] = "Options";
$lang['Add destination'] = "Add destination";
$lang['Edit Destination'] = "Edit Destination";

?>
