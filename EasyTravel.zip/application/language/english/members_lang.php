<?php
$lang['Username'] = "Username";
$lang['First name'] = "First name";
$lang['Last name'] = "Last name";
$lang['E-Mail'] = "E-Mail";
$lang['Role'] = "Role";
$lang['Options'] = "Options";
$lang['Edit'] = "Edit";
$lang['Delete'] = "Delete";
$lang['Add member'] = "Add member";
$lang['Password'] = "Password";
$lang['Repeat Password'] = "Repeat password";
$lang['Submit'] = "Submit";
$lang['Administrator'] = "Administrator";
$lang['Employee'] = "Employee";
$lang['Reseller'] = "Reseller";
$lang['Edit Member'] = "Edit Member";

?>
