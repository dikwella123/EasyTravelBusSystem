<?php
$lang['Dashboard'] = "Dashboard";
$lang['Bookings'] = "Bookings";
$lang['Members'] = "Members";
$lang['Destinations'] = "Destinations";
$lang['Tours'] = "Tours";
$lang['Clients'] = "Clients";
$lang['Statistics'] = "Statistics";
$lang['Settings'] = "Settings";
//  GLOBAL
$lang['Edit'] = "Edit";
$lang['Delete'] = "Delete";
$lang['Invoice'] = "Invoice";
$lang['Submit'] = "Submit";
$lang['Passangers list'] = "Passangers list";
$lang['Block'] = "Block";
$lang['Unblock'] = "Unblock";




?>
