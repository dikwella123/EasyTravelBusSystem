<?php
$lang['Company Name'] = "Company Name";
$lang['Street'] = "Street";
$lang['ZIP code'] = "ZIP code";
$lang['City'] = "City";
$lang['State'] = "State";
$lang['Phone number 1'] = "Phone number 1";
$lang['Phone number 2'] = "Phone number 2";
$lang['E-mail'] = "E-mail";
$lang['Currency'] = "Currency";
$lang['Rules and regulations'] = "Rules and regulations";
$lang['Save settings'] = "Save settings";

?>
