<?php
$lang['Statistics'] = "Statistics";
$lang['Tickets sold'] = "Tickets sold";
$lang['One way tickets income'] = "One way tickets income";
$lang['Round trip tickets income'] = "Round trip tickets income";
$lang['Total income'] = "Total income";
$lang['Update'] = "Update";

?>
