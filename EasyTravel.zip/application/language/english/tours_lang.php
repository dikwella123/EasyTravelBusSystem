<?php
$lang['Tours'] = "Tours";
$lang['Departure'] = "Departure";
$lang['Arrival'] = "Arrival";
$lang['Departure time'] = "Departure time";
$lang['Total seats'] = "Total seats";
$lang['Price'] = "Price";
$lang['Date created'] = "Date created";
$lang['Options'] = "Options";
$lang['Create tour'] = "Create tour";
$lang['First name'] = "First name";
$lang['Last name'] = "Last name";
$lang['ID number'] = "ID number";
$lang['Edit tour'] = "Edit tour";
$lang['Status'] = "Status";
$lang['Inactive'] = "Inactive";
$lang['Active'] = "Active";

$lang['Period'] = "Period";
$lang['From'] = "From date";
$lang['Until'] = "Until date";


?>
