<?php
$lang['First name'] = "Izina";
$lang['Last name'] = "Iri kiristu";
$lang['ID number'] = "Indangamuntu";
$lang['Departure'] = "Guhaguruka";
$lang['Arrival'] = "Kuhagera";
$lang['Departure time'] = "Igihe cyo guhaguruka";
$lang['Return time'] = "Igihe cyo kugaruka";
$lang['Booked by'] = "Yakatishijwe na";
$lang['Modified by'] = "Yahinduwe na";
$lang['Options'] = "options";
$lang['Book a ticket'] = "Katisha itike";
$lang['Search'] = "Shakisha";
$lang['Departure city'] = "Aho guhaguruka";
$lang['Arrival city'] = "Aho guhagarara";
$lang['Departure date'] = "Italiki yo guhaguruka";
$lang['Return date'] = "Itariki you kugaruka";
$lang['Tickets'] = "I tike";
$lang['Returning'] = "Kugarua";
$lang['Reset'] = "Gusubika";
$lang['Check available tours'] = "Reba ingendo zihari";
$lang['Optional'] = "Ntago ari ngomba";
$lang['Your search results will be displayed here'] = "Ibisubizo byo gushakisha biragara hano";
$lang['Destination'] = "Aho igiye";
$lang['Price'] = "Igiciro";
$lang['Next'] = "Ahakurikira";
$lang['Currently there are no tours available'] = "Ubungubu nta ngendo zihari";
$lang['from'] = 'Kuva';
$lang['to'] = 'Kujya';
$lang['Booking details'] = "Amakuru ajyanye no gukatisha itike";
$lang['Ticket details'] = "Ibijyanye n'itike";
$lang['Ticket(s) booked successfully'] = "I tike yakatishwijwe neza";
$lang['Ticket for'] = "Itike ya";
$lang['was booked successfully'] = "Yakatishijwe neza";
$lang['Print invoice'] = "Sohora inyemeza buguzi";
$lang['Go back to search'] = "Subira inyuma mw'ishakiro";



?>
