<?php
$lang['Clients'] = "Umu kiliya";
$lang['First name'] = "Izina ribanza";
$lang['Last name'] = "Izina riheruka";
$lang['ID number'] = "Indangamuntu";
$lang['Total tickets'] = "Umubare w'amatike";
$lang['Options'] = "Options";
$lang['Booking history'] = "Uruhererekane rw'amatike";
$lang['Search client'] = "Shaka umu client";
$lang['Departure'] = "Guhaguruka";
$lang['Arrival'] = "Guhagarara";
$lang['Direction'] = "Ikerekezo";
$lang['One way'] = "Inzira imwe";
$lang['Returning'] = "Kugaruka";
?>
