<?php
$lang['Your stats'] = "Incamake";
$lang['Your username'] = "Ijambo w'injiriraho";
$lang['Your role'] = "role";
$lang['Total tickets sold last 7 days'] = "Amatike yagurishijwe mu minsi 7 ishize";
$lang['Total tickets sold this month'] = "Amatike yagurishijwe mu kwezi gushize";
$lang['Total tickets sold'] = "Amatike yose yagurishijwe";
$lang['Dashboard'] = "Ikibaho";
$lang['Available tours'] = "Ingendo zihari";
$lang['Departure'] = "Guhaguruka";
$lang['Arrival'] = "Guhagarara";
$lang['Departure at'] = "Igihe cyo guhaguruka";
$lang['Quick booking'] = "Soza gukatisha itike";
$lang['Book ticket'] = "Katiza itike";
$lang['Search & Book Tickets'] = "Shakisha itike";
?>
