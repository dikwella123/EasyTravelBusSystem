<?php
$lang['Destinations'] = "Ikirekezo";
$lang['City'] = "Umujyi";
$lang['ISO name'] = "impine";
$lang['Options'] = "Optiosn";
$lang['Add Destination'] = "Ongeraho Ikirekezo";
$lang['Edit Destination'] = "Hindura Ikirekezo";


?>
