<?php
$lang['Username'] = "Izina w'injiriraho ";
$lang['First name'] = "Izina ribanza";
$lang['Last name'] = "Izina riheruka";
$lang['E-Mail'] = "E-Mail";
$lang['Role'] = "Icyo ukora";
$lang['Options'] = "Optiosn";
$lang['Edit'] = "Hindura";
$lang['Delete'] = "Siba";
$lang['Add Member'] = "Ongeramo umukozi";
$lang['Password'] = "Ijambo banga";
$lang['Repeat Password'] = "Subiramo ijambo banga";
$lang['Submit'] = "Emeza";
$lang['Administrator'] = "Administrator";
$lang['Employee'] = "Umukozi";
$lang['Reseller'] = "Umucuruzi";
$lang['Edit Member'] = "Hindura umunyamuryango";
?>
