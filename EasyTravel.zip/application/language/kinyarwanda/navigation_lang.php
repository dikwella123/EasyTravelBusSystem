<?php
$lang['Dashboard'] = "Ahabanza";
$lang['Bookings'] = "Guktisha amatike";
$lang['Members'] = "Abantu";
$lang['Destinations'] = "Ibyerekezo";
$lang['Tours'] = "Ingendo";
$lang['Clients'] = "Aba kiliya";
$lang['Statistics'] = "Imibare";
$lang['Settings'] = "Indemamujyo";
//  GLOBAL
$lang['Edit'] = "Hindura";
$lang['Delete'] = "Siba";
$lang['Invoice'] = "Inyemeza buguzi";
$lang['Submit'] = "Emeza";
$lang['Passangers list'] = "I lisiti yabagenzi";
$lang['Block'] = "Funga";
$lang['Unblock'] = "Fungura";




?>
