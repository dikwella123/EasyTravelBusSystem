<?php
$lang['Company Name'] = "Izina rya kompanyi";
$lang['Street'] = "Umuhanda";
$lang['ZIP code'] = "Kodi postal";
$lang['City'] = "Umujyi";
$lang['State'] = "Umujyi";
$lang['Phone number 1'] = "Numero ya telefoni 1";
$lang['Phone number 2'] = "Numero ya telefoni 2";
$lang['E-mail'] = "E-mail";
$lang['Currency'] = "Amafaranga";
$lang['Rules and regulations'] = "Amabwiriza";
$lang['Save settings'] = "Bika indemamujyo";

?>
