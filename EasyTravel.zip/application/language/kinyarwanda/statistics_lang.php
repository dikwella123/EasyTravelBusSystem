<?php
$lang['Statistics'] = "Raporo";
$lang['Tickets sold'] = "Amatike yagurishijwe";
$lang['One way tickets income'] = "Amafaranga y'amatike y'ikerekezo kimwe";
$lang['Round trip tickets income'] = "Amafaranga y'amatike y'ibyerekezo byinshi";
$lang['Total income'] = "Amafaranga yose yinjijwe";
$lang['Update'] = "Hindura";

?>
