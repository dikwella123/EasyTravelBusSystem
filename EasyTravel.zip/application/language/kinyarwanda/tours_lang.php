<?php
$lang['Tours'] = "Ingendo";
$lang['Departure'] = "Guhaguruka";
$lang['Arrival'] = "Guhagarara";
$lang['Departure time'] = "Igihe cyo guhaguruka";
$lang['Total seats'] = "Imyanya";
$lang['Price'] = "Igiciro";
$lang['Date created'] = "Igihe byashyiriwemo";
$lang['Options'] = "Options";
$lang['Create tour'] = "Ongeraho urugendo";
$lang['First name'] = "Izina ryambere";
$lang['Last name'] = "Izina rya kabiri";
$lang['ID number'] = "Indangamuntu";
$lang['Edit tour'] = "Hindura urugendo";
$lang['Status'] = "Uko bihagaze";
$lang['Inactive'] = "Ntago ari active";
$lang['Active'] = "Ni active";


?>
