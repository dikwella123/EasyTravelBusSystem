 <div class="col-sm-10 col-md-11 main">
          <div class="row" >
            <div class="col-sm-12 col-md-12" style="padding-left:0px;">
                <h1 class="page-header"><a href="<?php echo base_url().'admin/bookings' ?>"><i class="icon-arrow-left-3"></i></a> <?php echo lang('Book a ticket'); ?></h1>
            </div>
          </div>

          <?php echo Search::search_form() ?>
</div>
