<link href="../../../css/bootstrap.css" rel="stylesheet" type="text/css">
  
    <p class="copyright text-center"><strong>Easy Travel System By Perez Dikwella James Tel: +256 752062487</strong>  version: 5.0</p>
    </div><!-- #endof container-fluid-->
        <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="<?php echo base_url(); ?>/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>/js/docs.min.js"></script>
     <script src="<?php echo base_url(); ?>/js/moment.js"></script>
    <script src="<?php echo base_url(); ?>/js/datetimepicker.js"></script>

   </body>
</html>