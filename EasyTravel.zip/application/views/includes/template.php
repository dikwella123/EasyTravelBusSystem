<?php $this->load->view('includes/header'); ?>
 <div class="row">
 <?php $this->load->view('includes/navigation'); ?>	


<?php $this->load->view($main_content); ?>
 </div><!-- #endof row -->

<?php $this->load->view('includes/footer'); ?>